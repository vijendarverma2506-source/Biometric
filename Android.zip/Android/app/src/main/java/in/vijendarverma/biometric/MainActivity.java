package in.vijendarverma.biometric;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.Priority;
import com.google.android.gms.common.api.ResolvableApiException;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsControllerCompat;

public class MainActivity extends AppCompatActivity {
    private static final String HOME_URL = "https://vijendarverma.in/Biometric/employee/login.php";
    private WebView webView;
    private ProgressBar progress;
    private ValueCallback<Uri[]> fileCallback;
    private GeolocationPermissions.Callback pendingGeoCallback;
    private String pendingGeoOrigin;
    private PermissionRequest pendingCameraRequest;
    private static final int REQ_CAMERA = 201;
    private static final int REQ_LOCATION = 202;
    private static final int REQ_FILE = 203;
    private static final int REQ_LOCATION_SETTINGS = 204;
    private boolean pendingPunchLocationRequest = false;
    private boolean awaitingPunchSettingsReturn = false;
    private boolean punchSettingsVerificationRunning = false;
    private boolean punchCallbackDispatchRunning = false;
    private boolean pendingPunchReadyResult = false;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        setupSystemBars();
        showSplash();
        getWindow().getDecorView().postDelayed(this::showWebView, 2200);
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() {
                if (webView != null && webView.canGoBack()) webView.goBack();
                else new androidx.appcompat.app.AlertDialog.Builder(MainActivity.this)
                    .setMessage("Do you want to close Biometric?")
                    .setNegativeButton("Cancel", (d,w) -> d.dismiss())
                    .setPositiveButton("Exit", (d,w) -> finish()).show();
            }
        });
    }

    private void setupSystemBars() {
        Window window = getWindow();
        WindowCompat.setDecorFitsSystemWindows(window, false);
        window.setStatusBarColor(Color.TRANSPARENT);
        window.setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= 29) {
            window.setNavigationBarContrastEnforced(false);
            window.setStatusBarContrastEnforced(false);
        }
        // The supplied splash artwork already contains the phone status/navigation details.
        WindowInsetsControllerCompat bars =
            WindowCompat.getInsetsController(window, window.getDecorView());
        bars.hide(androidx.core.view.WindowInsetsCompat.Type.systemBars());
        bars.setSystemBarsBehavior(
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        );
    }

    private void showSystemBars() {
        Window window = getWindow();
        WindowInsetsControllerCompat bars =
            WindowCompat.getInsetsController(window, window.getDecorView());
        bars.show(androidx.core.view.WindowInsetsCompat.Type.systemBars());
        bars.setAppearanceLightStatusBars(false);
        bars.setAppearanceLightNavigationBars(false);
        window.setStatusBarColor(Color.rgb(5, 75, 160));
        window.setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= 29) window.setNavigationBarContrastEnforced(false);
    }

    private void showSplash() {
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(Color.WHITE);
        ImageView artwork = new ImageView(this);
        artwork.setImageResource(R.drawable.splash_screen);
        // FIT_CENTER keeps every part of the supplied splash artwork visible.
        artwork.setScaleType(ImageView.ScaleType.FIT_CENTER);
        artwork.setAdjustViewBounds(false);
        frame.addView(artwork, new FrameLayout.LayoutParams(-1, -1));
        setContentView(frame);
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void showWebView() {
        showSystemBars();
        FrameLayout root = new FrameLayout(this);
        webView = new WebView(this);
        webView.addJavascriptInterface(new AndroidLocationBridge(), "AndroidLocation");
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgressTintList(android.content.res.ColorStateList.valueOf(Color.rgb(8,120,237)));
        FrameLayout.LayoutParams barParams = new FrameLayout.LayoutParams(-1, dp(3), Gravity.TOP);
        root.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        root.addView(progress, barParams);
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(root, (view, insets) -> {
            androidx.core.graphics.Insets bars = insets.getInsets(
                androidx.core.view.WindowInsetsCompat.Type.systemBars()
            );
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });
        setContentView(root);

        // Keep PHP's long-lived employee session cookie across app restarts.
        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(true);
        settings.setGeolocationEnabled(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.setBackgroundColor(Color.WHITE);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean onRenderProcessGone(WebView view, android.webkit.RenderProcessGoneDetail detail) {
                // Recover from a WebView renderer crash instead of closing the whole app.
                FrameLayout parent = (FrameLayout) view.getParent();
                if (parent != null) parent.removeView(view);
                view.destroy();
                webView = null;
                showWebView();
                return true;
            }

            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                // Persist PHP Set-Cookie values (including the 10-year employee session cookie).
                CookieManager.getInstance().flush();
                if (pendingPunchLocationRequest) dispatchPunchLocationResultWhenPageReady(0);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return routeUrl(url);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return routeUrl(request.getUrl().toString());
            }
            private boolean routeUrl(String rawUrl) {
                Uri uri = Uri.parse(rawUrl);
                String scheme = uri.getScheme() == null ? "" : uri.getScheme();
                if ("https".equalsIgnoreCase(scheme) && uri.getHost() != null &&
                    (uri.getHost().equalsIgnoreCase("vijendarverma.in") || uri.getHost().toLowerCase().endsWith(".vijendarverma.in"))) return false;
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    return true;
                }
                return true;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int value) {
                progress.setProgress(value);
                progress.setVisibility(value >= 100 ? View.GONE : View.VISIBLE);
            }
            @Override public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> {
                    boolean asksVideo = false;
                    for (String r : request.getResources())
                        if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) asksVideo = true;
                    if (!asksVideo) { request.deny(); return; }
                    if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
                    } else {
                        pendingCameraRequest = request;
                        requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
                    }
                });
            }
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                pendingGeoOrigin = origin;
                pendingGeoCallback = callback;
                if (hasLocationPermission()) {
                    ensureLocationSettings();
                } else {
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
                }
            }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = params.createIntent();
                try { startActivityForResult(intent, REQ_FILE); return true; }
                catch (Exception e) { fileCallback = null; Toast.makeText(MainActivity.this, "File picker unavailable", Toast.LENGTH_SHORT).show(); return false; }
            }
        });
        // Always start at the employee login page when the app is launched.
        webView.loadUrl(HOME_URL);
    }

    // JavaScript bridge used by the employee Punch In/Out button.
    // It checks Android location settings on every punch tap and returns the result
    // to the page without showing a custom web loading overlay.
    private final class AndroidLocationBridge {
        // Read the device GPS switch only. Do not open Android Location Accuracy/settings.
        @JavascriptInterface
        public void checkDeviceGpsStatus() {
            runOnUiThread(() -> {
                boolean enabled = false;
                try {
                    LocationManager manager = (LocationManager) getSystemService(LOCATION_SERVICE);
                    if (manager != null) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                            enabled = manager.isLocationEnabled();
                        } else {
                            enabled = manager.isProviderEnabled(LocationManager.GPS_PROVIDER)
                                || manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
                        }
                    }
                } catch (Exception ignored) {
                    enabled = false;
                }
                if (webView != null) {
                    final boolean gpsEnabled = enabled;
                    webView.evaluateJavascript(
                        "if(window.onNativeGpsStatus){window.onNativeGpsStatus(" + gpsEnabled + ");}",
                        null
                    );
                }
            });
        }

        @JavascriptInterface
        public void requestPunchLocation() {
            runOnUiThread(() -> {
                pendingPunchLocationRequest = true;
                if (hasLocationPermission()) {
                    ensurePunchLocationSettings();
                } else {
                    requestPermissions(new String[]{
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                    }, REQ_LOCATION);
                }
            });
        }
    }

    private void completePunchLocationRequest(boolean ready) {
        if (!pendingPunchLocationRequest) return;
        awaitingPunchSettingsReturn = false;
        punchSettingsVerificationRunning = false;
        pendingPunchReadyResult = ready;
        dispatchPunchLocationResultWhenPageReady(0);
    }

    // Preserve the native result until the employee page has registered its JS callback.
    private void dispatchPunchLocationResultWhenPageReady(int attempt) {
        if (!pendingPunchLocationRequest || isFinishing()) {
            punchCallbackDispatchRunning = false;
            return;
        }
        if (punchCallbackDispatchRunning) return;
        if (webView == null) {
            retryPunchCallbackDispatch(attempt);
            return;
        }

        punchCallbackDispatchRunning = true;
        final String js = "(function(){"
            + "if(typeof window.onNativePunchLocationReady !== 'function') return 'NOT_READY';"
            + "try { window.onNativePunchLocationReady(" + (pendingPunchReadyResult ? "true" : "false") + ");"
            + "return 'DELIVERED'; } catch(e) { return 'CALLBACK_ERROR'; }"
            + "})()";

        webView.post(() -> {
            if (webView == null || !pendingPunchLocationRequest) {
                punchCallbackDispatchRunning = false;
                return;
            }
            webView.evaluateJavascript(js, value -> {
                punchCallbackDispatchRunning = false;
                if ("\"DELIVERED\"".equals(value)) {
                    pendingPunchLocationRequest = false;
                    awaitingPunchSettingsReturn = false;
                    punchSettingsVerificationRunning = false;
                } else {
                    retryPunchCallbackDispatch(attempt);
                }
            });
        });
    }

    private void retryPunchCallbackDispatch(int attempt) {
        if (!pendingPunchLocationRequest) return;
        if (attempt >= 30) {
            punchCallbackDispatchRunning = false;
            return;
        }
        mainHandler.postDelayed(() -> dispatchPunchLocationResultWhenPageReady(attempt + 1), 200L);
    }

    private void ensurePunchLocationSettings() {
        LocationRequest request = new LocationRequest.Builder(
            Priority.PRIORITY_HIGH_ACCURACY, 10000L
        ).build();
        LocationSettingsRequest settings = new LocationSettingsRequest.Builder()
            .addLocationRequest(request)
            .setAlwaysShow(true)
            .build();

        LocationServices.getSettingsClient(this).checkLocationSettings(settings)
            .addOnSuccessListener(response -> {
                // Never report ready only because Google Play services accepted the request.
                // The Android device-wide Location switch must also be ON.
                if (isDeviceLocationEnabled()) {
                    completePunchLocationRequest(true);
                } else {
                    openDeviceLocationSettingsForPunch();
                }
            })
            .addOnFailureListener(error -> {
                if (error instanceof ResolvableApiException) {
                    try {
                        awaitingPunchSettingsReturn = true;
                        ((ResolvableApiException) error).startResolutionForResult(
                            MainActivity.this, REQ_LOCATION_SETTINGS
                        );
                    } catch (Exception launchError) {
                        awaitingPunchSettingsReturn = false;
                        if (!isDeviceLocationEnabled()) openDeviceLocationSettingsForPunch();
                        else completePunchLocationRequest(false);
                    }
                } else if (!isDeviceLocationEnabled()) {
                    openDeviceLocationSettingsForPunch();
                } else {
                    completePunchLocationRequest(false);
                }
            });
    }

    // Fallback for Android/OEM builds where SettingsClient reports success even
    // though the device-wide Location switch is OFF. Return to this Activity and
    // verify the real setting before allowing the web page to open the camera.
    private void openDeviceLocationSettingsForPunch() {
        if (!pendingPunchLocationRequest || isFinishing()) return;
        try {
            awaitingPunchSettingsReturn = true;
            startActivityForResult(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS), REQ_LOCATION_SETTINGS);
        } catch (Exception e) {
            awaitingPunchSettingsReturn = false;
            completePunchLocationRequest(false);
        }
    }

    // Confirm both Android's device-wide Location switch and the GPS provider are ON.
    private boolean isDeviceLocationEnabled() {
        LocationManager manager = (LocationManager) getSystemService(LOCATION_SERVICE);
        if (manager == null) return false;
        try {
            boolean masterEnabled;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                masterEnabled = manager.isLocationEnabled();
            } else {
                masterEnabled = manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
                    || manager.isProviderEnabled(LocationManager.GPS_PROVIDER);
            }
            return masterEnabled && manager.isProviderEnabled(LocationManager.GPS_PROVIDER);
        } catch (Exception e) {
            return false;
        }
    }

    private boolean hasLocationPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    /**
     * Ask Android/Google Play services to show its native Location Settings resolution dialog
     * when device location or high-accuracy location settings are disabled.
     */
    private void ensureLocationSettings() {
        LocationRequest locationRequest = new LocationRequest.Builder(
            Priority.PRIORITY_HIGH_ACCURACY, 10000L
        ).build();

        LocationSettingsRequest settingsRequest = new LocationSettingsRequest.Builder()
            .addLocationRequest(locationRequest)
            .setAlwaysShow(true)
            .build();

        LocationServices.getSettingsClient(this)
            .checkLocationSettings(settingsRequest)
            .addOnSuccessListener(response -> completePendingGeolocation(true))
            .addOnFailureListener(error -> {
                if (error instanceof ResolvableApiException) {
                    try {
                        ((ResolvableApiException) error).startResolutionForResult(
                            MainActivity.this, REQ_LOCATION_SETTINGS
                        );
                    } catch (Exception launchError) {
                        completePendingGeolocation(false);
                    }
                } else {
                    completePendingGeolocation(false);
                }
            });
    }

    private void completePendingGeolocation(boolean granted) {
        if (pendingGeoCallback != null) {
            pendingGeoCallback.invoke(pendingGeoOrigin, granted, true);
            pendingGeoCallback = null;
            pendingGeoOrigin = null;
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQ_CAMERA && pendingCameraRequest != null) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) pendingCameraRequest.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
            else pendingCameraRequest.deny();
            pendingCameraRequest = null;
        } else if (requestCode == REQ_LOCATION) {
            if (pendingPunchLocationRequest) {
                if (hasLocationPermission()) ensurePunchLocationSettings();
                else completePunchLocationRequest(false);
            } else if (pendingGeoCallback != null) {
                if (hasLocationPermission()) ensureLocationSettings();
                else completePendingGeolocation(false);
            }
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE && fileCallback != null) {
            Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        } else if (requestCode == REQ_LOCATION_SETTINGS) {
            // Some Android/OEM builds return RESULT_CANCELED even when the user
            // enabled Location. Never trust the result code: verify the real setting.
            if (pendingPunchLocationRequest) {
                awaitingPunchSettingsReturn = false;
                verifyPunchLocationAfterReturn(0);
            } else if (resultCode == Activity.RESULT_OK) {
                ensureLocationSettings();
            } else {
                completePendingGeolocation(false);
            }
        }
    }

    @Override protected void onResume() {
        super.onResume();
        // The Settings resolution screen can resume the app without a reliable
        // Activity result on some devices. Re-check after returning to this Activity.
        if (pendingPunchLocationRequest && awaitingPunchSettingsReturn) {
            awaitingPunchSettingsReturn = false;
            mainHandler.postDelayed(() -> verifyPunchLocationAfterReturn(0), 650L);
        }
    }

    private void verifyPunchLocationAfterReturn(int attempt) {
        if (!pendingPunchLocationRequest || isFinishing()) return;
        if (punchSettingsVerificationRunning) {
            if (attempt < 8) mainHandler.postDelayed(() -> verifyPunchLocationAfterReturn(attempt + 1), 400L);
            return;
        }
        punchSettingsVerificationRunning = true;
        LocationRequest request = new LocationRequest.Builder(
            Priority.PRIORITY_HIGH_ACCURACY, 10000L
        ).build();
        LocationSettingsRequest settings = new LocationSettingsRequest.Builder()
            .addLocationRequest(request)
            .setAlwaysShow(true)
            .build();
        LocationServices.getSettingsClient(this).checkLocationSettings(settings)
            .addOnSuccessListener(response -> {
                punchSettingsVerificationRunning = false;
                awaitingPunchSettingsReturn = false;
                completePunchLocationRequest(true);
            })
            .addOnFailureListener(error -> {
                punchSettingsVerificationRunning = false;
                if (attempt < 8) {
                    mainHandler.postDelayed(() -> verifyPunchLocationAfterReturn(attempt + 1), 500L);
                } else {
                    awaitingPunchSettingsReturn = false;
                    completePunchLocationRequest(false);
                }
            });
    }

    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + .5f); }

    @Override protected void onPause() {
        if (webView != null) webView.onPause();
        CookieManager.getInstance().flush();
        super.onPause();
    }

    @Override protected void onDestroy() {
        CookieManager.getInstance().flush();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
